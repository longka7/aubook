<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Mẹ Bầu - Aubook</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background-color: #F8F9FA;
            color: #333;
            line-height: 1.6;
        }

        .dashboard-header {
            background: linear-gradient(135deg, #FF7B9C 0%, #FFA8B8 100%);
            color: white;
            padding: 24px 20px;
        }

        .header-content {
            max-width: 600px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .dashboard-header h1 {
            font-size: 1.5rem;
        }

        .btn-logout {
            padding: 8px 16px;
            background: rgba(255, 255, 255, 0.2);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-size: 0.9rem;
        }

        .dashboard-main {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
        }

        .card {
            background: white;
            border-radius: 16px;
            padding: 24px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }

        .card h2,
        .card h3 {
            margin-bottom: 16px;
            color: #333;
        }

        .info-row {
            display: flex;
            justify-content: space-between;
            padding: 12px 0;
            border-bottom: 1px solid #F0F0F0;
        }

        .info-row:last-child {
            border-bottom: none;
        }

        .info-row .label {
            color: #666;
            font-size: 0.95rem;
        }

        .info-row .value {
            color: #333;
            font-weight: 600;
        }

        .info-row .value.highlight {
            color: #FF7B9C;
        }

        .progress-bar {
            width: 100%;
            height: 12px;
            background: #E0E0E0;
            border-radius: 6px;
            overflow: hidden;
            margin: 16px 0 8px;
        }

        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #FF7B9C 0%, #FFA8B8 100%);
            border-radius: 6px;
            transition: width 0.5s ease;
        }

        .progress-text {
            text-align: center;
            color: #666;
            font-size: 0.9rem;
        }

        .share-link-box {
            display: flex;
            gap: 10px;
            margin-top: 12px;
        }

        .share-link-box input {
            flex: 1;
            padding: 12px;
            border: 2px solid #E0E0E0;
            border-radius: 8px;
            font-size: 0.95rem;
        }

        .btn-copy {
            padding: 12px 20px;
            background: #FF7B9C;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
        }

        .empty-state p {
            color: #666;
            margin-bottom: 20px;
        }

        .btn-primary {
            display: inline-block;
            padding: 12px 24px;
            background: linear-gradient(135deg, #FF7B9C 0%, #FFA8B8 100%);
            color: white;
            text-decoration: none;
            border-radius: 10px;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <header class="dashboard-header">
        <div class="header-content">
            <h1>Chào mừng, <?php echo htmlspecialchars($_SESSION['full_name']); ?>! 👋</h1>
            <a href="index.php?action=logout" class="btn-logout">Đăng xuất</a>
        </div>
    </header>

    <main class="dashboard-main">
        <?php if($pregnancy_info): ?>
        <div class="card">
            <h2>Thông tin Thai kỳ</h2>
            <div class="info-row">
                <span class="label">Ngày thụ thai:</span>
                <span class="value"><?php echo date('d/m/Y', strtotime($pregnancy_info['conception_date'])); ?></span>
            </div>
            <div class="info-row">
                <span class="label">Ngày dự sinh:</span>
                <span class="value highlight"><?php echo date('d/m/Y', strtotime($pregnancy_info['due_date'])); ?></span>
            </div>
            <div class="info-row">
                <span class="label">Tuần thai:</span>
                <span class="value">
                    <?php 
                        $conception = new DateTime($pregnancy_info['conception_date']);
                        $now = new DateTime();
                        $diff = $conception->diff($now);
                        $weeks = floor($diff->days / 7);
                        $days = $diff->days % 7;
                        echo $weeks . ' tuần ' . $days . ' ngày';
                    ?>
                </span>
            </div>
            <div class="info-row">
                <span class="label">Còn lại:</span>
                <span class="value">
                    <?php 
                        $due = new DateTime($pregnancy_info['due_date']);
                        $remaining = $now->diff($due);
                        echo $remaining->days . ' ngày';
                    ?>
                </span>
            </div>
        </div>

        <div class="card">
            <h3>Tiến trình thai kỳ</h3>
            <div class="progress-bar">
                <div class="progress-fill" style="width: <?php 
                    $total_days = 280;
                    $passed_days = $diff->days;
                    $percentage = min(100, ($passed_days / $total_days) * 100);
                    echo $percentage;
                ?>%"></div>
            </div>
            <p class="progress-text"><?php echo round($percentage); ?>% hoàn thành</p>
        </div>

        <div class="card">
            <h3>💡 Lời khuyên hôm nay</h3>
            <p>Hãy uống đủ nước, nghỉ ngơi đầy đủ và tập thể dục nhẹ nhàng. Đừng quên bổ sung vitamin cho mẹ và bé!</p>
        </div>

        <div class="card">
            <h3>Chia sẻ với người thân</h3>
            <p>Mời người thân theo dõi hành trình thai kỳ cùng bạn</p>
            <div class="share-link-box">
                <input type="text" id="shareLink" value="tenapp.com/<?php echo $_SESSION['user_id']; ?>" readonly>
                <button class="btn-copy" onclick="copyShareLink()">Sao chép</button>
            </div>
        </div>

        <?php else: ?>
        <div class="empty-state">
            <p>Chưa có thông tin thai kỳ</p>
            <a href="index.php?action=pregnancy_info" class="btn-primary">Nhập thông tin</a>
        </div>
        <?php endif; ?>
    </main>

    <script>
        function copyShareLink() {
            const linkInput = document.getElementById('shareLink');
            linkInput.select();
            document.execCommand('copy');
            alert('Đã sao chép link!');
        }
    </script>
</body>
</html>