<?php
// index.php - Router chính

// Thiết lập múi giờ Việt Nam - SỬA LỖI MÚI GIỜ
date_default_timezone_set('Asia/Ho_Chi_Minh');

require_once 'controllers/AuthController.php';
require_once 'controllers/PregnancyController.php';
require_once 'controllers/FamilyController.php';

$action = $_GET['action'] ?? 'index';

// Routing
switch($action) {
    // Auth routes
    case 'index':
        $controller = new AuthController();
        $controller->index();
        break;
    
    case 'select_role':
        $controller = new AuthController();
        $controller->selectRole();
        break;
    
    case 'register_form':
        $controller = new AuthController();
        $controller->registerForm();
        break;
    
    case 'send_otp':
        $controller = new AuthController();
        $controller->sendOTP();
        break;
    
    case 'verify_otp':
        $controller = new AuthController();
        $controller->verifyOTP();
        break;
    
    case 'register':
        $controller = new AuthController();
        $controller->register();
        break;
    
    case 'login':
        $controller = new AuthController();
        $controller->login();
        break;
    
    case 'logout':
        $controller = new AuthController();
        $controller->logout();
        break;
    
    // Pregnancy routes
    case 'pregnancy_info':
        $controller = new PregnancyController();
        $controller->pregnancyInfo();
        break;
    
    case 'save_pregnancy_info':
        $controller = new PregnancyController();
        $controller->savePregnancyInfo();
        break;
    
    case 'pregnancy_dashboard':
        $controller = new PregnancyController();
        $controller->dashboard();
        break;
    
    // Family routes
    case 'search_pregnant':
        $controller = new FamilyController();
        $controller->searchPregnant();
        break;
    
    case 'find_pregnant':
        $controller = new FamilyController();
        $controller->findPregnant();
        break;
    
    case 'connect_pregnant':
        $controller = new FamilyController();
        $controller->connectPregnant();
        break;
    
    case 'family_dashboard':
        $controller = new FamilyController();
        $controller->dashboard();
        break;
    
    default:
        header('HTTP/1.0 404 Not Found');
        echo '404 - Page Not Found';
        break;
}
?>